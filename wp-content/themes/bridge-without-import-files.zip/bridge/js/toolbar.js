// $j(window).load(function(){
	// setTimeout(function(){
		// $j("#panel.default").animate({marginLeft: "0px"});
		// $j("a.open").addClass('opened');
		// $j("#panel").addClass('opened-panel');
	// },1000);
// });

var tooltip1 = '<div class="tooltip tooltip1"><a href="#" class="tooltip_marker"></a> \
									<div class="popup_tooltip popup_tooltip1"> \
										<div class="popup_tooltip_inner"><i class="fa fa-times"></i> \
											<div class="tooltip_row clearfix"> \
													<h5 class="tooltip_title">Header Options</h5> \
													<p>Bridge theme comes with an amazing new Qode functionality - choose main menu colors from slide to slide and from page to page. Combine it with dark/light header backgrounds to create beautiful contrasts between pages.</p> \
													<h5>Try a different style</h5> \
													<img class="tooltip_image_1" src="http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_1.jpg" alt="&nbsp;" /> \
													<a class="qbutton small white tooltip_link_1" href="#">Change</a> \
											</div> \
										</div> \
									</div> \
								</div>\
								';
var tooltip2 = '<div class="tooltip_container"><div class="tooltip tooltip2"><a href="#" class="tooltip_marker"></a> \
									<div class="popup_tooltip popup_tooltip2"> \
										<div class="popup_tooltip_inner"><i class="fa fa-times"></i> \
											<div class="tooltip_row clearfix"> \
													<h5 class="tooltip_title">Footer Options</h5> \
													<p>Choose different footer types, regular or unfold. </p> \
													<h5>Try a different style</h5> \
													<img class="tooltip_image_2" src="http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_2.jpg" alt="&nbsp;" /> \
													<a class="qbutton small white tooltip_link_2" href="#">Change</a> \
											</div> \
										</div> \
									</div> \
								</div></div>\
								';


$j(window).load(function(){

    if((window.location.href.indexOf("bridge/") > -1 || window.location.href.indexOf("bridge2/") > -1) || (window.location.href.indexOf("bridge3/") == -1  && window.location.href.indexOf("bridge4/") == -1 && window.location.href.indexOf("bridge5/") == -1 && window.location.href.indexOf("bridge6/") == -1 && window.location.href.indexOf("bridge7/") == -1 && window.location.href.indexOf("bridge8/") == -1 && window.location.href.indexOf("bridge9/") == -1 && window.location.href.indexOf("bridge10/") == -1 && window.location.href.indexOf("bridge11/") == -1 && window.location.href.indexOf("bridge12/") == -1 && window.location.href.indexOf("bridge13/") == -1 && window.location.href.indexOf("bridge14/") == -1 && window.location.href.indexOf("bridge15/") == -1 && window.location.href.indexOf("bridge16/") == -1 && window.location.href.indexOf("bridge17/") == -1 && window.location.href.indexOf("bridge18/") == -1 && window.location.href.indexOf("bridge19/") == -1 && window.location.href.indexOf("bridge20/") == -1 && window.location.href.indexOf("bridge21/") == -1  && window.location.href.indexOf("bridge22/") == -1  && window.location.href.indexOf("bridge23/") == -1  && window.location.href.indexOf("bridge24/") == -1  && window.location.href.indexOf("bridge25/") == -1 && window.location.href.indexOf("bridge26/") == -1 && window.location.href.indexOf("bridge27/") == -1 && window.location.href.indexOf("bridge28/") == -1 && window.location.href.indexOf("bridge29/") == -1 && window.location.href.indexOf("bridge30/") == -1 && window.location.href.indexOf("bridge31/") == -1 && window.location.href.indexOf("bridge32/") == -1 && window.location.href.indexOf("bridge33/") == -1 && window.location.href.indexOf("bridge34/") == -1 && window.location.href.indexOf("bridge35/") == -1 && window.location.href.indexOf("bridge36/") == -1 && window.location.href.indexOf("bridge37/") == -1 && window.location.href.indexOf("bridge38/") == -1 && window.location.href.indexOf("bridge39/") == -1 && window.location.href.indexOf("bridge40/") == -1 && window.location.href.indexOf("bridge41/") == -1 && window.location.href.indexOf("bridge42/") == -1 && window.location.href.indexOf("bridge43/") == -1 && window.location.href.indexOf("bridge44/") == -1 && window.location.href.indexOf("bridge45/") == -1)) {
        $j('header .header_bottom .container_inner').append(tooltip1);
        $j('.content').append(tooltip2);
    }

    setTimeout(function(){
        if((window.location.href.indexOf("bridge/") > -1) || (window.location.href.indexOf("bridge2/") == -1 && window.location.href.indexOf("bridge3/") == -1  && window.location.href.indexOf("bridge4/") == -1 && window.location.href.indexOf("bridge5/") == -1 && window.location.href.indexOf("bridge6/") == -1 && window.location.href.indexOf("bridge7/") == -1 && window.location.href.indexOf("bridge8/") == -1 && window.location.href.indexOf("bridge9/") == -1 && window.location.href.indexOf("bridge10/") == -1 && window.location.href.indexOf("bridge11/") == -1 && window.location.href.indexOf("bridge12/") == -1 && window.location.href.indexOf("bridge13/") == -1 && window.location.href.indexOf("bridge14/") == -1 && window.location.href.indexOf("bridge15/") == -1 && window.location.href.indexOf("bridge16/") == -1 && window.location.href.indexOf("bridge17/") == -1 && window.location.href.indexOf("bridge18/") == -1 && window.location.href.indexOf("bridge19/") == -1 && window.location.href.indexOf("bridge20/") == -1 && window.location.href.indexOf("bridge21/") == -1 && window.location.href.indexOf("bridge22/") == -1 && window.location.href.indexOf("bridge23/") == -1 && window.location.href.indexOf("bridge24/") == -1 && window.location.href.indexOf("bridge25/") == -1 && window.location.href.indexOf("bridge26/") == -1 && window.location.href.indexOf("bridge27/") == -1 && window.location.href.indexOf("bridge28/") == -1 && window.location.href.indexOf("bridge29/") == -1 && window.location.href.indexOf("bridge30/") == -1 && window.location.href.indexOf("bridge31/") == -1 && window.location.href.indexOf("bridge32/") == -1 && window.location.href.indexOf("bridge33/") == -1 && window.location.href.indexOf("bridge34/") == -1 && window.location.href.indexOf("bridge35/") == -1 && window.location.href.indexOf("bridge36/") == -1 && window.location.href.indexOf("bridge37/") == -1 && window.location.href.indexOf("bridge38/") == -1 && window.location.href.indexOf("bridge39/") == -1 && window.location.href.indexOf("bridge40/") == -1) && window.location.href.indexOf("bridge41/") == -1 && window.location.href.indexOf("bridge42/") == -1 && window.location.href.indexOf("bridge43/") == -1 && window.location.href.indexOf("bridge44/") == -1 && window.location.href.indexOf("bridge45/") == -1) {
            $j('#toolbar').animate({bottom: "0px"});
        }else{
            $j('#toolbar').animate({bottom: -($j('#toolbar').height() - 108)+"px"});
            $j('#toolbar').removeClass('on');
            $j('#toolbar').addClass('off');
            $j("#toolbar a.open").removeClass('opened');
        }
        $j('#toolbar').css({'visibility':'visible'});
    },1000);

    // after site load  load all images that are not loaded - start //
    $j('#toolbar .website_holder .toolbar_image').each(function() {
        var $this = $j(this);
        if ( $this.find('img').attr('data-src')) {
            var src = $this.find('img').data('src');
            var newImg = new Image();
            newImg.src = src;
            $j(newImg).load(function(){
                $this.find('.loading_more_examples').fadeOut(100, function (){
                    $this.find('img').attr("src", newImg.src).removeAttr('data-src');
                });
            });
        }

    });
    // after site load  load all images that are not loaded - start //

});

$j(document).ready(function() {
	
	
	
	$j(document).on( "click", ".tooltip .tooltip_marker", function(){
		$j(".popup_tooltip").hide(300);
		var $this = $j(this);
		
		if ($this.next(".popup_tooltip").is(":visible")){           
			$this.next(".popup_tooltip").find(".popup_tooltip_inner").animate({opacity:0},100);
			$this.next(".popup_tooltip").hide(300);
    }
    else{      
			$this.next(".popup_tooltip").show(300, function(){
				$this.next(".popup_tooltip").find(".popup_tooltip_inner").animate({opacity:1},600);
			});
    }
    return false;
	});
	
	$j(document).on( "click", ".tooltip .popup_tooltip_inner i", function(){
		$j(".popup_tooltip").hide(300);
		
		$j(this).closest(".popup_tooltip").find(".popup_tooltip_inner").animate({opacity:0},100);
		$j(this).closest(".popup_tooltip").hide(300);  
		
    return false;
	});
	
	$j(document).click(function() {
		$j(".tooltip .popup_tooltip").hide(300);
		$j(".tooltip .popup_tooltip .popup_tooltip_inner").animate({opacity:0},100);
		$j(".tooltip .popup_tooltip").hide(300);
		
	});

	$j(document).on( "click", ".tooltip", function(event){
		event.stopPropagation();
	});
	
	$j(document).on( "click", ".tooltip_link_1", function(e){
		e.preventDefault();
		if(!$j(this).hasClass('clicked')){
			$j(this).addClass('clicked');
			$j('html').addClass('normal_header');
			$j('.tooltip_image_1').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_1_reverse.jpg');
		}else{
			$j(this).removeClass('clicked');
			$j('html').removeClass('normal_header');
			$j('.tooltip_image_1').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_1.jpg');
		}
	});
	
	$j(document).on( "click", ".tooltip_link_2", function(e){
		e.preventDefault();
		if(!$j(this).hasClass('clicked')){
            $j(this).addClass('clicked');
            $j('footer').addClass('uncover');
            $j('.content').removeClass('normal_footer_content');
            $j('.tooltip_image_2').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_2_reverse.jpg');
            setContentBottomMargin();
		}else{
            $j(this).removeClass('clicked');
            $j('footer').removeClass('uncover');
            $j('.content').addClass('normal_footer_content');
            $j('.tooltip_image_2').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_2.jpg');
		}

        $j(".popup_tooltip").hide(300);

        $j(this).closest(".popup_tooltip").find(".popup_tooltip_inner").animate({opacity:0},100);
        $j(this).closest(".popup_tooltip").hide(300);
    });
	
	$j('ul#tootlbar_header_color li').click(function(e){
		e.preventDefault();
		if($j(this).attr("data-value") != "white"){
			$j('.tooltip_link_1').addClass('clicked');
			$j('html').addClass('dark_header');
			$j('.tooltip_image_1').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_1_reverse.jpg');
		}else{
			$j('.tooltip_link_1').removeClass('clicked');
			$j('html').removeClass('dark_header');
			$j('.tooltip_image_1').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_1.jpg');
		}
	});
	
	
	$j('ul#tootlbar_footer_type li').click(function(e){
		e.preventDefault();
		if($j(this).attr("data-value") != "unfold"){
			$j('.tooltip_link_2').addClass('clicked');
			$j('footer').removeClass('uncover');
			$j('.content').addClass('normal_footer_content');
			$j('.tooltip_image_2').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_2_reverse.jpg');
		}else{
			$j('.tooltip_link_2').removeClass('clicked');
			$j('footer').addClass('uncover');
			$j('.content').removeClass('normal_footer_content');
			$j('.tooltip_image_2').attr('src','http://demo.qodeinteractive.com/bridge/demo_images/tooltip_image_2.jpg');
            setContentBottomMargin();
		}

        if($j('.uncover').length && $j('body').hasClass('vertical_menu_enabled') && $window_width > 1000){
            $j('.uncover').width($window_width -  $j('.vertical_menu_area').width());
        } else{
            $j('.uncover').css('width','100%');
        }
	});
	
	
	$j("#panel.default.left a.open").click(function(e){
		e.preventDefault();
		var margin_left = $j("#panel.default").css("margin-left");
		if (margin_left == "-207px"){
			$j("#panel.default").animate({marginLeft: "0px"});
			$j("#panel.default").addClass('opened-panel');
			$j(this).addClass('opened');
		}
		else{
			$j("#panel.default").animate({marginLeft: "-207px"});
			$j(this).removeClass('opened');
			$j("#panel.default").removeClass('opened-panel');
		}
		return false;
	});

    $j("#panel.default.right a.open").click(function(e){
        e.preventDefault();
        var margin_right = $j("#panel.default").css("margin-right");
        if (margin_right == "-207px"){
            $j("#panel.default").animate({marginRight: "0px"});
            $j("#panel.default").addClass('opened-panel');
            $j(this).addClass('opened');
        }
        else{
            $j("#panel.default").animate({marginRight: "-207px"});
            $j(this).removeClass('opened');
            $j("#panel.default").removeClass('opened-panel');
        }
        return false;
    });
	
	$j(".accordion_toolbar").accordion({
		animate: "swing",
		collapsible: true,
		active: 6,
		icons: "",
		heightStyle: "content"
	});
	
	$j('ul#tootlbar_header_top_menu li').click(function(){
		if($j(this).attr("data-value") != ""){
			
    	$j.post(qode_root+'updatesession.php', {proya_header_top : $j(this).attr("data-value")}, function(data){
				location.reload();
			});
		}
	});
	
	$j('ul#tootlbar_smooth_scroll li').click(function(){
		if($j(this).attr("data-value") != ""){
    	$j.post(qode_root+'updatesession.php', {proya_smooth : $j(this).attr("data-value")}, function(data){
				location.reload();
			});
		}
	});

	$j('ul#tootlbar_page_transitions li').click(function(){
		if($j(this).attr("data-value") != ""){

			$j.post(qode_root+'updatesession.php', {proya_page_transitions : $j(this).attr("data-value")}, function(data){
				location.reload();
			});
		}
	});

	$j('ul#tootlbar_header_type li').click(function(){
		if($j(this).attr("data-value") != ""){
    	$j.post(qode_root+'updatesession.php', {proya_header_type : $j(this).attr("data-value")}, function(data){
					location.reload();
			});
		}
	});

    $j('ul#tootlbar_alternative_menu li').click(function(){
        if($j(this).attr("data-value") != ""){
            $j.post(qode_root+'updatesession.php', {proya_alternative_menu : $j(this).attr("data-value")}, function(data){
                location.reload();
            });
        }
    });
	
	$j('ul#tootlbar_pattern li').click(function(){

		$j('body.boxed .wrapper').removeClass('toolbar_clicked');
		jQuery('#tootlbar_pattern_css').remove();
		
		if($j(this).attr("data-value") != "no"){
			//$j('#tootlbar_boxed').getSetSSValue('boxed');
			//$j('#tootlbar_background').getSetSSValue('no');
			$j('body').addClass('boxed');
			newSkin ="body.boxed .wrapper { \
									background-image: url('http://demo.qodeinteractive.com/bridge/demo_images/"+$j(this).attr("data-value")+".png'); \
									background-position: 0px 0px; \
									background-repeat: repeat; \
								} \
							";
			jQuery('body').append('<style id="tootlbar_pattern_css" type="text/css">'+newSkin+'</style>'); 
			
		}else{
			newSkin ="body { \
									background-image: none; \
								} \
							";
			jQuery('body').append('<style id="tootlbar_pattern_css" type="text/css">'+newSkin+'</style>'); 
		}
	});
	
	$j('ul#tootlbar_background li').click(function(){
	
	$j('body.boxed .wrapper').removeClass('toolbar_clicked');
	jQuery('#tootlbar_background_css').remove();
		if($j(this).attr("data-value") != "no"){
			//$j('#tootlbar_boxed').getSetSSValue('boxed');
			//$j('#tootlbar_pattern').getSetSSValue('no');
			$j('body').addClass('boxed');
			newSkin ="body.boxed .wrapper { \
									background-image: url('http://demo.qodeinteractive.com/bridge/demo_images/"+$j(this).attr("data-value")+".jpg'); \
									background-position: 0px 0px; \
									background-repeat: repeat; \
									background-attachment: fixed; \
								} \
							";
			jQuery('body').append('<style id="tootlbar_background_css" type="text/css">'+newSkin+'</style>'); 
			
		}else{
			newSkin ="body { \
									background-image: none; \
								} \
							";
			jQuery('body').append('<style id="tootlbar_background_css" type="text/css">'+newSkin+'</style>'); 
		}
	});
	
	$j('ul#tootlbar_boxed li').click(function(){
	
		$j('body').removeClass('boxed');
		$j('body').addClass($j(this).attr("data-value"));

		$j('body.boxed .wrapper').addClass('toolbar_clicked');

	});	
	
	$j('ul#tootlbar_tooltips li').click(function(){
		if($j(this).attr("data-value") != "yes"){
			$j('.tooltip').css('visibility','hidden');
		}else{
			$j('.tooltip').css('visibility','visible');
		}
	});
	
	$j('div#tootlbar_hide_sections li input').change(function(){
		var id = $j(this).val();
		if(this.checked){
			$j("div.wpb_row[data-q_id='" + id + "'],section.parallax_section_holder[data-q_id='" + id + "']").fadeIn();
    }else{
			$j("div.wpb_row[data-q_id='" + id + "'],section.parallax_section_holder[data-q_id='" + id + "']").fadeOut();
		}
	});
	
	$j('#tootlbar_colors .color').each(function(){
		$j(this).on('click',function(){
			$j('#tootlbar_colors .color').removeClass('active');
			$j(this).addClass('active');
			var color = $j(this).data('color');
			
			if ($j("#toolbar_colors_css").length > 0){
				$j("#toolbar_colors_css").remove();
			}
			newSkin ="	h1 a:hover,\
						h2 a:hover,\
						h3 a:hover,\
						h4 a:hover,\
						h5 a:hover,\
						h6 a:hover,\
						p a:hover,\
						nav.mobile_menu ul li a:hover,\
						nav.mobile_menu ul li.active > a,\
						.breadcrumb .current,\
						.breadcrumb a:hover,\
						.box_image_holder .box_icon .fa-stack i.fa-stack-base,\
						.q_counter_holder span.counter,\
						.box_holder_icon .fa-stack i,\
						.q_percentage_with_icon,\
						.filter_holder ul li.active span,\
						.filter_holder ul li:hover span,\
						.q_tabs .tabs-nav li.active a:hover,\
						.q_tabs .tabs-nav li a:hover,\
						.q_accordion_holder.accordion .ui-accordion-header:hover,\
						.q_accordion_holder.accordion.with_icon .ui-accordion-header i,\
						.testimonials .testimonial_text_inner p.testimonial_author span.author_company,\
						.testimonial_content_inner .testimonial_author .company_position,\
						.q_dropcap,\
						.q_icon_with_title .icon_with_title_link,\
						.q_icon_with_title.center .icon_holder .font_awsome_icon i:hover,\
						.q_box_holder.with_icon .box_holder_icon_inner .fa-stack i.fa-stack-base,\
						.q_font_awsome_icon_stack .fa-circle,\
						.q_icon_with_title.boxed .icon_holder .fa-stack,\
						.q_font_awsome_icon i,\
						.q_font_awsome_icon i:hover,\
						.q_progress_bars_icons_inner.square .bar.active i,\
						.q_progress_bars_icons_inner.circle .bar.active i,\
						.q_progress_bars_icons_inner.normal .bar.active i,\
						.q_progress_bars_icons_inner .bar.active i.fa-circle,\
						.q_list.number ul>li:before,\
						.q_social_icon_holder:hover i.simple_social,\
						.social_share_dropdown ul li :hover i,\
						.social_share_list_holder ul li i:hover,\
						.latest_post_inner .post_infos a:hover,\
						.q_masonry_blog article .q_masonry_blog_post_info a:hover,\
						.blog_holder article .post_info a:hover,\
						.latest_post_inner .post_comments:hover i,\
						.blog_holder article .post_description a:hover,\
						.blog_holder article .post_description .post_comments:hover,\
						.blog_like a:hover i,\
						.blog_like a.liked i,\
						.blog_like a:hover span,\
						.comment_holder .comment .text .replay,\
						.comment_holder .comment .text .comment-reply-link,\
						.header-widget.widget_nav_menu ul.menu li a:hover,\
						aside .widget a:hover,\
						aside .widget.posts_holder li:hover,\
						.footer_top .q_social_icon_holder:hover i.simple_social,\
						.q_steps_holder .circle_small:hover span,\
						.q_steps_holder .circle_small:hover .step_title,\
						.header_top #lang_sel > ul > li > a:hover,\
						.header_top #lang_sel_click > ul > li> a:hover,\
						.header_top #lang_sel_list ul li a.lang_sel_sel,\
						.header_top #lang_sel_list ul li a:hover,\
						aside .widget #lang_sel a.lang_sel_sel:hover,\
						aside .widget #lang_sel_click a.lang_sel_sel:hover,\
						aside .widget #lang_sel ul ul a:hover,\
						aside .widget #lang_sel_click ul ul a:hover,\
						aside .widget #lang_sel_list li a.lang_sel_sel,\
						aside .widget #lang_sel_list li a:hover,\
						.service_table_inner li.service_table_title_holder i,\
						.myaccount_user a,\
						.woocommerce .select2-results li.select2-highlighted,\
						.woocommerce-page .select2-results li.select2-highlighted,\
						.woocommerce-checkout .chosen-container .chosen-results li.active-result.highlighted,\
						.woocommerce-account .chosen-container .chosen-results li.active-result.highlighted,\
						.woocommerce ins, .woocommerce-page ins,\
						.woocommerce ul.products li.product:hover h6,\
						.woocommerce div.product div.product_meta > span a:hover,\
						.woocommerce div.cart-collaterals div.cart_totals table tr.order-total strong span.amount,\
						.woocommerce-page div.cart-collaterals div.cart_totals table tr.order-total strong span.amount,\
						.woocommerce div.cart-collaterals div.cart_totals table tr.order-total strong,\
						.woocommerce .checkout-opener-text a,\
						.woocommerce form.checkout table.shop_table tfoot tr.order-total th,\
						.woocommerce form.checkout table.shop_table tfoot tr.order-total td span.amount,\
						.woocommerce aside ul.product_list_widget li > a:hover,\
						.woocommerce aside ul.product-categories li > a:hover,\
						.woocommerce aside ul.product_list_widget li span.amount,\
						.woocommerce aside .widget ul.product-categories a:hover,\
						.woocommerce-page aside .widget ul.product-categories a:hover,\
						.shopping_cart_header .header_cart:hover i,\
						.shopping_cart_dropdown ul li a:hover,\
						.shopping_cart_dropdown .cart_list span.quantity,\
						.more_facts_button:hover,\
						.q_team .q_team_social_holder .q_social_icon_holder:hover i.simple_social,\
						.single_tags a:hover { \
							color: "+color+"; \
					} \
                        .custom_color .qbutton:hover {\
                            color: "+color+" !important; \
                        }\
						.box_image_with_border:hover,\
						.qbutton:hover,\
						.qbutton.view-cart:hover, \
						.load_more a:hover,\
						.blog_load_more_button a,\
						#submit_comment:hover,\
						.drop_down .wide .second ul li .qbutton:hover,\
						.drop_down .wide .second ul li ul li .qbutton:hover,\
						.qbutton.green,\
						.portfolio_slides .hover_feature_holder_inner .qbutton:hover,\
						.testimonials_holder.light .flex-direction-nav a:hover,\
						.q_progress_bars_icons_inner.square .bar.active .bar_noactive,\
						.q_progress_bars_icons_inner.square .bar.active .bar_active,\
						.q_progress_bars_icons_inner.circle .bar.active .bar_noactive,\
						.q_progress_bars_icons_inner.circle .bar.active .bar_active,\
						.widget.widget_search form.form_focus,\
						.q_steps_holder .circle_small_wrapper,\
						.animated_icon_inner span.animated_icon_back i,\
						.woocommerce .button:hover,\
						.woocommerce-page .button:hover,\
						.woocommerce #submit:hover,\
						.woocommerce ul.products li.product a.qbutton:hover,\
						.woocommerce-page ul.products li.product a.qbutton:hover,\
						.woocommerce ul.products li.product .added_to_cart:hover,\
						.projects_holder article a.preview:hover,\
						.projects_holder article a.lightbox:hover{ \
							border-color: "+color+"; \
					    } \
                        \
                        .custom_color .qbutton,\
                        .q_circles_holder .q_circle_inner2:hover,\
                        .custom_color .q_circles_holder .q_circle_inner2:hover,\
                        .q_social_icon_holder.circle_social .fa-stack:hover,\
                        .call_to_action .qbutton:not(.white):hover,\
                        .price_button .qbutton:hover,\
                        .q_slider .item:not(.dark) .qbutton:hover{ \
                            border-color: "+color+" !important; \
                        }\
                        \
			       		.q_icon_list i,\
						.q_progress_bar .progress_content,\
						.q_progress_bars_vertical .progress_content_outer .progress_content,\
						.load_more a:hover,\
						.blog_load_more_button a,\
						#submit_comment:hover,\
						.drop_down .wide .second ul li .qbutton:hover,\
						.drop_down .wide .second ul li ul li .qbutton:hover,\
						.qbutton.green,\
						.highlight,\
						.testimonials_holder.light .flex-direction-nav a:hover,\
						.q_dropcap.circle,\
						.q_dropcap.square,\
						.q_price_table.active .active_text,\
						.q_icon_with_title.boxed .icon_holder .fa-stack,\
						.q_font_awsome_icon_square,\
						.q_icon_with_title.square .icon_holder .fa-stack:hover,\
						.box_holder_icon_inner.square .fa-stack:hover,\
						.box_holder_icon_inner.circle .fa-stack:hover,\
						.circle .icon_holder .fa-stack:hover,\
						.q_list.number.circle_number ul>li:before,\
						.q_social_icon_holder.circle_social .fa-stack:hover,\
						.social_share_dropdown ul li.share_title,\
						.latest_post_holder .latest_post_date .post_publish_day,\
						.q_masonry_blog article.format-link:hover,\
						.q_masonry_blog article.format-quote:hover,\
						.blog_holder article.format-link .post_text:hover .post_text_inner,\
						.blog_holder article.format-quote .post_text:hover .post_text_inner,\
						#wp-calendar td#today,\
						.vc_text_separator.full div,\
						.mejs-controls .mejs-time-rail .mejs-time-current,\
						.mejs-controls .mejs-time-rail .mejs-time-handle,\
						.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current,\
						.q_pie_graf_legend ul li .color_holder,\
						.q_line_graf_legend ul li .color_holder,\
						.q_team .q_team_text_inner .separator,\
						.circle_item .circle:hover,\
						.qode_call_to_action.container,\
						.qode_carousels .flex-control-paging li a.flex-active,\
						.animated_icon_inner span.animated_icon_back i,\
						.woocommerce .button:hover,\
						.woocommerce-page .button:hover,\
						.woocommerce #submit:hover,\
						.woocommerce ul.products li.product a.qbutton:hover,\
						.woocommerce-page ul.products li.product a.qbutton:hover,\
						.woocommerce ul.products li.product .added_to_cart:hover,\
						.woocommerce .quantity .minus:hover,\
						.woocommerce #content .quantity .minus:hover,\
						.woocommerce-page .quantity .minus:hover,\
						.woocommerce-page #content .quantity .minus:hover,\
						.woocommerce .quantity .plus:hover,\
						.woocommerce #content .quantity .plus:hover,\
						.woocommerce-page .quantity .plus:hover,\
						.woocommerce-page #content .quantity .plus:hover,\
						.woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-range,\
						.woocommerce-page .widget_price_filter .ui-slider-horizontal .ui-slider-range,\
						.q_circles_holder .q_circle_inner2:hover,\
						.custom_color .call_to_action,\
						.custom_color .q_counter_holder .separator.small,\
						.custom_color .qbutton,\
						.custom_color blockquote,\
						.price_button .qbutton:hover,\
						.portfolio_slides .hover_feature_holder_inner .qbutton:hover,\
						.projects_holder article a.preview:hover,\
						.projects_holder article a.lightbox:hover { \
			           		 background-color: "+color+" !important; \
			        } \
			        .custom_color .qbutton:not(.white):hover {\
			            background-color: transparent !important;\
			        }\
			        .call_to_action,\
			        .qbutton:hover,\
			        .qbutton.view-cart:hover, \
			        .q_message,\
			        .custom_color .q_message,\
			         .q_slider .item:not(.dark) .qbutton:hover {\
			            background-color: "+color+"; \
			        }\
			        \
			        .qbutton.green:hover { \
			            background-color: #fff !important; \
			        }\
			        \
                    .q_slider .item .qbutton.green:hover {\
                        border-color: #fff !important;\
                    }\
					";
				jQuery('body').append('<style id="toolbar_colors_css" type="text/css">'+newSkin+'</style>');
		});
	});

    $j(".menu_switcher a.menu_open").click(function(e){
        e.preventDefault();
        var bottom = $j(".menu_switcher").css("bottom");
        if (bottom == "-291px"){
            $j(".menu_switcher").animate({bottom: "0px"});
            $j(this).addClass('opened');
            $j(".menu_switcher a.menu_open span i").removeClass('fa-chevron-up').addClass('fa-times');
        }
        else{
            $j(".menu_switcher").animate({bottom: "-291px"});
            $j(this).removeClass('opened');
            $j(".menu_switcher a.menu_open span i").removeClass('fa-times').addClass('fa-chevron-up');
        }
        return false;
    });

    // logic for toolbar examples switcher - start //

    var toolbar_height = $j('#toolbar').height() - 108; //108 is height of open/close button
    $j("#toolbar_outer").height(toolbar_height).niceScroll({
        scrollspeed: 30,
        mousescrollstep: 20,
        cursorwidth: 0,
        cursorborder: 0,
        cursorborderradius: 0,
        cursorcolor: "transparent",
        autohidemode: false,
        horizrailenabled: false
    });

    $j( window ).resize(function() {
        toolbar_height = $j('#toolbar').height() - 108; //108 is height of open/close button
        if ($j('#toolbar').hasClass('off')){
            $j('#toolbar').css({'bottom': -toolbar_height});
        }
        $j('#toolbar_outer').height(toolbar_height).getNiceScroll().resize();
    });

    $j("#toolbar span.open span.opener").click(function(e){

        if ($j('#toolbar').hasClass('off')){
            $j('#toolbar').stop().animate({'bottom': '0px'});
            $j('#toolbar').removeClass('off');
            $j('#toolbar').addClass('on');
        }
        else{
            $j('#toolbar').stop().animate({'bottom': -toolbar_height});
            $j('#toolbar').removeClass('on');
            $j('#toolbar').addClass('off');
        }

    });

    $j(document).on("mouseenter","#toolbar #toolbar_outer .website_holder:not(.placeholder)",function() {

        var src = $j(this).data('image');
        var newImg = new Image();
        newImg.src = src;
        $j(newImg).load(function(){
            $j("#toolbar .toolbar_preview .loading_more_examples").fadeOut(100, function (){
                $j("#toolbar .toolbar_preview").append(newImg);
            });
        });

    });

    $j(document).on("mouseenter","#toolbar #toolbar_outer .website_holder:not(.placeholder)",function() {
        $j("#toolbar .toolbar_preview").addClass("show");
    }).on("mouseleave","#toolbar #toolbar_outer .website_holder:not(.placeholder)",function() {
        $j("#toolbar .toolbar_preview").removeClass("show");
        $j("#toolbar .toolbar_preview img").remove();
        $j("#toolbar .toolbar_preview .loading_more_examples").stop().fadeIn(100);
    });

    $j("#toolbar #toolbar_outer .website_holder.placeholder").on('mouseenter',function() {
        $j("#toolbar .toolbar_preview").removeClass("show");
        $j("#toolbar .toolbar_preview img").remove();
        $j("#toolbar .toolbar_preview .loading_more_examples").stop().fadeIn(100);
    });

    // logic for toolbar examples switcher - end //


    // logic for infinite scroll - start //
    //var count_examples = 1;
    //var max_examples = 7;
    //$j('#toolbar_outer').scrollLoad({
    //    getData : function() {
    //
    //    },
    //    start : function() {
    //        $j('<div class="loading_more_examples"><div class="five_rotating_circles"><div class="spinner-container container1"><div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div></div><div class="spinner-container container2"><div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div></div><div class="spinner-container container3"><div class="circle1"></div><div class="circle2"></div><div class="circle3"></div><div class="circle4"></div></div></div></div>').appendTo('#toolbar');
    //    },
    //    ScrollAfterHeight : 90,	//this is the height in percentage
    //
    //    onload : function( data ) {
    //        $j(this).find('#toolbar_inner2').append( data );
    //        $j('#toolbar_outer').getNiceScroll().resize();
    //        $j('#toolbar > .loading_more_examples').remove();
    //    },
    //    continueWhile : function( resp ) {
    //        if( count_examples >= max_examples ) {
    //            return false;
    //        }
    //        count_examples++;
    //        return true;
    //    }
    //});
    // logic for infinite scroll - end //

    // logic for lazy load images in main menu - start //
    $j(document).on("mouseenter",".drop_down .wide .second ul li.show_widget_area_in_popup",function() {
        var $this = $j(this);
        var src = $j(this).find('.textwidget a img').data('src');
        var newImg = new Image();
        newImg.src = src;
        if(!$j(this).find('.textwidget a img').hasClass('changed')) {
            $j(newImg).load(function () {
                $this.find('.loading_more_examples').fadeOut(100,function(){
                    $j(this).remove();
                });
                $this.find('.textwidget a img').attr("src", src).addClass('changed');

            });
        }
    });
    // logic for lazy load images in main menu - end //


    //add call to action in 'demos' menu item on Bridge Original - start //
    if(window.location.href.indexOf("bridge/") > -1 || window.location.href.indexOf("bridge1000/") > -1){
        $j('#nav-menu-item-14859 .second .inner').prepend( "<div class='see_all'><div class='see_all_inner'><p>Bridge Theme comes with 42+ amazing easy-to-import demos</p><a href='#' class='qbutton green'>See All Demos</a></div></div>" );
    }
    //add call to action in 'demos' menu item on Bridge Original - end //
}); 

function hexToRgb(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

$j.fn.inlineStyle = function (prop) {
	 var styles = this.attr("style"),
		 value;
	 styles && styles.split(";").forEach(function (e) {
		 var style = e.split(":");
		 if ($j.trim(style[0]) === prop) {
			 value = style[1];           
		 }                    
	 });   
	 return value;
};