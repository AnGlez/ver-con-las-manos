<?php

$options_fontstyle = array( "normal" => "normal",
 "italic" => "italic"
);
$options_fontweight = array( "200" => "200",
 "300" => "300",
 "400" => "400",
 "500" => "500",
 "600" => "600",
 "700" => "700",
 "800" => "800",
 "900" => "900"
);
$options_texttransform = array( "none" => "None",
 "capitalize" => "Capitalize",
 "uppercase" => "Uppercase",
 "lowercase" => "Lowercase"
);

$options_fontdecoration = array( "none" => "none",
 "underline" => "underline"
);