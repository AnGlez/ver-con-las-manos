bridge.zip - full theme
bridge-child.zip - child theme
bridge-without-import-files.zip - full theme without one-click import files (bridge/includes/import/files/ content deleted) - ideal for updating theme